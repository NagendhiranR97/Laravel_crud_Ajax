<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student details</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" >
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container mt-2">
    <div class="row">
        <div class="col-md-12 card-header text-center font-weight-bold">
          <h2>Ajax Student details</h2>
        </div>
        <div class="col-md-12 mt-1 mb-2"><button type="button" id="addNewstudent" class="btn btn-success">Add</button></div>
        <div class="col-md-12">
            <table class="table">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">first_name</th>
                  <th scope="col">last_name</th>
                  <th scope="col">email</th>
                  <th scope="col">city_name</th>
                  <th scope="col">Actions</th>
                </tr>
              </thead>
              <tbody> 
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($student->id); ?></td>
                    <td><?php echo e($student->first_name); ?></td>
                    <td><?php echo e($student->last_name); ?></td>
                    <td><?php echo e($student->email); ?></td>
                    <td><?php echo e($student->city_name); ?></td>
                    <td>
                       <a href="javascript:void(0)" class="btn btn-primary edit" data-id="<?php echo e($student->id); ?>">Edit</a>
                      <a href="javascript:void(0)" class="btn btn-primary delete" data-id="<?php echo e($student->id); ?>">Delete</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            
        </div>
    </div>        
</div>
<!-- boostrap model -->
    <div class="modal fade" id="ajax-student-model" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <div class="modal-header">
            <h4 class="modal-title" id="ajaxstudentModel"></h4>
          </div>
          <div class="modal-body">
            <form action="javascript:void(0)" id="addEditstudentForm" name="addEditstudentForm" class="form-horizontal" method="POST">
              <input type="hidden" name="id" id="id">
              <div class="form-group">
                <label for="name" class="col-sm-2 control-label">First Name</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="first_name" name="first_name" placeholder="Enter student Name" value="" maxlength="50" required="">
                </div>
              </div>
              <div class="form-group">
                <label for="name" class="col-sm-2 control-label">Last Name</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="last_name" name="last_name" placeholder="Enter student Name" value="" maxlength="50" required="">
                </div>
              </div> 
              <!-- <div class="form-group">
                <label for="name" class="col-sm-2 control-label">student Code</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="code" name="code" placeholder="Enter student Code" value="" maxlength="50" required="">
                </div>
              </div>
              <div class="form-group">
                <label class="col-sm-2 control-label">student Author</label>
                <div class="col-sm-12">
                  <input type="text" class="form-control" id="author" name="author" placeholder="Enter author Name" value="" required="">
                </div>
              </div> -->
              <div class="form-group">
              <label class="col-sm-2 control-label">Email</label>
              <input type="email" name="email" id="email" class="form-control" placeholder="Email Id" value="" required="">
            </div>

              <div class="form-group">
              <label class="col-sm-2 control-label">City</label>
              <select name="city_name" id="city_name" class=" form-control" required>
                <option value="delhi">Delhi</option>
                <option value="mumbai">Mumbai</option>
                <option value="kolkata">Kolkata</option>
                <option value="chennai">Chennai</option>
              </select>
            </div>
              <div class="col-sm-offset-2 col-sm-10">
                <button type="submit" class="btn btn-primary" id="btn-save" value="addNewstudent">Save changes
                </button>
              </div>
            </form>
          </div>
          <div class="modal-footer">
            
          </div>
        </div>
      </div>
    </div>
<!-- end bootstrap model -->
<script type="text/javascript">
 $(document).ready(function($){
    $.ajaxSetup({
        headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('#addNewstudent').click(function () {
       $('#addEditstudentForm').trigger("reset");
       $('#ajaxstudentModel').html("Add student");
       $('#ajax-student-model').modal('show');
    });
 
    $('body').on('click', '.edit', function () {
        var id = $(this).data('id');
         
        // ajax
        $.ajax({
            type:"POST",
            url: "<?php echo e(url('edit-student')); ?>",
            data: { id: id },
            dataType: 'json',
            success: function(res){
              $('#ajaxstudentModel').html("Edit student");
              $('#ajax-student-model').modal('show');
              $('#id').val(res.id);
              $('#first_name').val(res.first_name);
              $('#last_name').val(res.last_name);
              $('#email').val(res.email);
              $('#city_name').val(res.city_name);
           }
        });
    });
    $('body').on('click', '.delete', function () {
       if (confirm("Delete Record?") == true) {
        var id = $(this).data('id');
         
        // ajax
        $.ajax({
            type:"POST",
            url: "<?php echo e(url('delete-student')); ?>",
            data: { id: id },
            dataType: 'json',
            success: function(res){
              window.location.reload();
           }
        });
       }
    });
    $('body').on('click', '#btn-save', function (event) {
          var id = $("#id").val();
          var first_name = $("#first_name").val();
          var last_name = $("#last_name").val();
          var email = $("#email").val();
          var city_name = $("#city_name").val();
          $("#btn-save").html('Please Wait...');
          $("#btn-save"). attr("disabled", true);
         
        // ajax
        $.ajax({
            type:"POST",
            url: "<?php echo e(url('add-update-student')); ?>",
            data: {
              id:id,
              first_name:first_name,
              last_name:last_name,
              email:email,
              city_name:city_name,
            },
            dataType: 'json',
            success: function(res){
             window.location.reload();
            $("#btn-save").html('Submit');
            $("#btn-save"). attr("disabled", false);
           }
        });
    });
});
</script>
</body>
</html><?php /**PATH C:\Rathish Nagendhiran\Projects\Crud-Nagendhiran-Laravel\resources\views/student/main.blade.php ENDPATH**/ ?>
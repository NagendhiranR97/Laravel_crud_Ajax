

<?php $__env->startSection('content'); ?>
<div class="container">
	<?php print_r($studetails);?>
	<h1 class="page-title">StudentsTutorial Add Form</h1>
	<div class="" style="margin-bottom:10px;margin-top:15px;">
	</div>
	<div class="row justify-content-center">
		<div class="col-md-6">
			<div class="card">
				
				<div class="card-header">Add</div>
				<div class="card-body">
					<?php if(session('status')): ?>
						<div class="alert alert-success" role="alert">
							<?php echo e(session('status')); ?>

						</div>
					<?php elseif(session('failed')): ?>
						<div class="alert alert-danger" role="alert">
							<?php echo e(session('failed')); ?>

						</div>
					<?php endif; ?>
					<form method="POST" action="<?php echo e(url('create')); ?>" class="needs-validation" novalidate>
						<?php echo csrf_field(); ?>
						<div class="form-group">
							<label>First Name:</label>
							<input type="text" name="first_name" id="first_name" class=" form-control col-sm-6 <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="First Name" value="<?php echo e(old('first_name')); ?>" required />
							<?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div class="invalid-feedback">
									<?php echo e($message); ?>

								</div>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						  
						</div>
						<div class="form-group">
							<label>Last Name:</label>
							<input type="text" name="last_name" id="last_name" class=" form-control col-sm-6 <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Last Name" value="<?php echo e(old('last_name')); ?>" required />
							<?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div class="invalid-feedback">
									<?php echo e($message); ?>

								</div>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						  
						</div>
						<div class="form-group">
							<label>Email:</label>
							<input type="email" name="email" id="email_id" class="form-control col-sm-6 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Email Id" value="<?php echo e(old('email')); ?>" required / >
							<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<div class="invalid-feedback">
									<?php echo e($message); ?>

								</div>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
						<div class="form-group">
							<label>City:</label>
							<select name="city_name" id="city_name" class=" form-control col-sm-6 <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
								<option value="delhi">Delhi</option>
								<option value="mumbai">Mumbai</option>
								<option value="kolkata">Kolkata</option>
								<option value="chennai">Chennai</option>
							</select>
						</div>
						<button type="submit" class="btn btn-primary">Save</button>
					  </form>				   
				</div>
			</div>
		</div>
		<div class="col-md-6">
			<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">FirstName</th>
      <th scope="col">LastName</th>
      <th scope="col">Email</th>
      <th scope="col">City</th>
      <th scope="col">Edit</th>
      <th scope="col">delete</th>
    </tr>
  </thead>
  <tbody>
   <tr>
                          <td> <?php echo e($studetails['first_name']); ?> </td>
                          <td> <?php echo e($studetails['last_name']); ?> </td>
                          <td> <?php echo e($studetails['city_name']); ?> </td>
                          <td> <?php echo e($studetails['email']); ?> </td>
                          <td>
                            <div class="col-sm-6 col-md-4 col-lg-3" style="max-width: 100%;">
                        <!-- <a href="<?php echo e(route('category.edit', ['categoryId' => $category['_id'], ])); ?>"><button class="btn btn-info align-text-top border-0"><i class="fa fa-edit"></i></button></a> -->
                      </div>
                          </td>
                          <td>
                             <div class="col-sm-6 col-md-4 col-lg-3" style="max-width: 100%;">
                         <!-- <a href="<?php echo e(route('category.delete', ['categoryId' => $category['_id'], ])); ?>">
                        <button class="btn btn-info align-text-top border-0"><i class="fa fa-trash-o"></i></button>
                      </a> -->
                      </div>
                          </td>
                        </tr>
  </tbody>
</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Rathish Nagendhiran\Projects\sci_flare\sciflare\resources\views/student/add.blade.php ENDPATH**/ ?>
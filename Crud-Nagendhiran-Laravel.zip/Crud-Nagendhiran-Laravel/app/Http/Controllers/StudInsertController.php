<?php

namespace App\Http\Controllers;
use App\Http\Controllers\Controller;
use App\Models\StudInsert;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;

class StudInsertController extends Controller
{

    public function index()
    {
        $data['students'] = StudInsert::orderBy('id','desc')->paginate(5);
   
        return view('student.main',$data);
    }

    public function store(Request $request)
    {
        $studentdetails   =   StudInsert::updateOrCreate(
                    [
                        'id' => $request->id
                    ],
                    [
                        'first_name' => $request->first_name, 
                        'last_name' => $request->last_name,
                        'city_name' => $request->city_name,
                        'email' => $request->email,
                    ]);
    
        return response()->json(['success' => true]);
    }
    
    public function edit(Request $request)
    {   
        $where = array('id' => $request->id);
        $studentdetails  = StudInsert::where($where)->first();
 
        return response()->json($studentdetails);
    }
 
   
    
    public function destroy(Request $request)
    {
        $studentdetails = StudInsert::where('id',$request->id)->delete();
   
        return response()->json(['success' => true]);
    }
}